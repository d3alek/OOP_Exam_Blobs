﻿namespace Blobs.Interfaces
{
    public interface IAttacker
    {
        void PerformAttack(IBlob target);
    }
}