﻿namespace Blobs.Interfaces
{
    public interface IRunnable
    {
        void Run();
    }
}