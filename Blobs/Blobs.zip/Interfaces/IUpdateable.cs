﻿namespace Blobs.Interfaces
{
    public interface IUpdateable
    {
        void Update();
    }
}